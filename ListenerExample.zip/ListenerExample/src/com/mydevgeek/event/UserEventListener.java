package com.mydevgeek.event;

import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class UserEventListener{

    @EventListener
    public void handleUserEvent(UserEvent event) {
        //do some operations
        System.out.println(event.getUser().getUsername());
    }
}