package com.mydevgeek.app;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mydevgeek.controller.MainController;

@ComponentScan(basePackages = "com.mydevgeek")
public class Application {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		context.start();
		MainController ctrllr = (MainController) context.getBean("mainController");
		ctrllr.userLogin("Jay", false);
		context.stop();
		context.close();
	}
}